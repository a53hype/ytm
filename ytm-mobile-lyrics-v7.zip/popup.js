const toggleEl = document.getElementById("toggleEnabled");
const badgeEl = document.getElementById("stateBadge");
const sourceEl = document.getElementById("sourceText");
const trackTitleEl = document.getElementById("trackTitle");
const reasonEl = document.getElementById("reasonText");
const refreshBtn = document.getElementById("refreshBtn");

function renderToggleState(enabled) {
  toggleEl.checked = enabled;
  badgeEl.textContent = enabled ? "ON • PRIORITY" : "OFF";
  badgeEl.classList.toggle("off", !enabled);
}

async function init() {
  const { enabled } = await chrome.storage.local.get(["enabled"]);
  const isEnabled = typeof enabled === "boolean" ? enabled : true;
  renderToggleState(isEnabled);

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || !tab.url?.includes("music.youtube.com")) {
    sourceEl.textContent = "Not on YouTube Music";
    trackTitleEl.textContent = "Switch to a music.youtube.com tab";
    return;
  }

  chrome.runtime.sendMessage({ type: "GET_TAB_STATUS", tabId: tab.id }, (res) => {
    const st = res?.status;
    if (!st) {
      sourceEl.textContent = "Waiting for playback";
      trackTitleEl.textContent = "Play a song and open the Lyrics tab";
      return;
    }

    trackTitleEl.textContent = st.title
      ? `${st.title}${st.artist ? " — " + st.artist : ""}`
      : `Video ID: ${st.videoId || "None"}`;
    sourceEl.textContent = st.synced ? `Source: ${st.source}` : "No YT Synced Lyrics";
    reasonEl.textContent = st.reason || "";
  });
}

toggleEl.addEventListener("change", async () => {
  const nextVal = toggleEl.checked;
  await chrome.storage.local.set({ enabled: nextVal });
  renderToggleState(nextVal);
});

refreshBtn.addEventListener("click", async () => {
  await chrome.runtime.sendMessage({ type: "CLEAR_CACHE_AND_REFRESH" });
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab?.id && tab.url?.includes("music.youtube.com")) {
    chrome.tabs.sendMessage(tab.id, { type: "FORCE_REFRESH_LYRICS" });
  }
  setTimeout(init, 500);
});

init();
