const MAX_CACHE_ENTRIES = 250;
const cache = new Map();
const tabStatus = new Map();

chrome.runtime.onInstalled.addListener(async () => {
  const existing = await chrome.storage.local.get(["enabled"]);
  if (typeof existing.enabled !== "boolean") {
    await chrome.storage.local.set({ enabled: true });
  }
});

function buildAndroidContext(hl = "en", gl = "US") {
  return {
    client: {
      clientName: "ANDROID_MUSIC",
      clientVersion: "7.21.50",
      androidSdkVersion: 34,
      hl,
      gl
    }
  };
}

function setCache(key, value) {
  if (cache.size >= MAX_CACHE_ENTRIES) {
    const oldestKey = cache.keys().next().value;
    cache.delete(oldestKey);
  }
  cache.set(key, value);
}

chrome.tabs.onRemoved.addListener((tabId) => {
  tabStatus.delete(tabId);
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "FETCH_YOUTUBE_MOBILE_LYRICS") {
    getYouTubeLyrics(message, sender?.tab?.id)
      .then((result) => sendResponse({ ok: true, data: result }))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message?.type === "GET_TAB_STATUS") {
    const status = tabStatus.get(message.tabId) || null;
    sendResponse({ ok: true, status });
    return false;
  }

  if (message?.type === "CLEAR_CACHE_AND_REFRESH") {
    cache.clear();
    sendResponse({ ok: true });
    return false;
  }

  return false;
});

async function getYouTubeLyrics({ videoId, title, artist, hl, gl, forceRefresh }, tabId) {
  if (!videoId) {
    const empty = { synced: false, lines: [], source: "None", reason: "No video ID detected" };
    if (typeof tabId === "number") tabStatus.set(tabId, { videoId: "", title, artist, ...empty });
    return empty;
  }

  const cacheKey = `${videoId}:${hl || "en"}:${gl || "US"}`;
  if (!forceRefresh && cache.has(cacheKey)) {
    const cached = cache.get(cacheKey);
    if (typeof tabId === "number") tabStatus.set(tabId, { videoId, title, artist, ...cached });
    return cached;
  }

  const result = await fetchYouTubeMobileLyrics(videoId, hl, gl);
  const finalResult = result || {
    synced: false,
    lines: [],
    source: "None",
    reason: "No timed lyrics available on YouTube"
  };

  setCache(cacheKey, finalResult);
  if (typeof tabId === "number") {
    tabStatus.set(tabId, { videoId, title, artist, ...finalResult });
  }
  return finalResult;
}

async function fetchYouTubeMobileLyrics(videoId, hl, gl) {
  const context = buildAndroidContext(hl || "en", gl || "US");

  try {
    const nextRes = await fetch(
      "https://music.youtube.com/youtubei/v1/next?prettyPrint=false&ytm_mobile_sync=1",
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          context,
          videoId
        })
      }
    );

    if (!nextRes.ok) {
      return {
        synced: false,
        lines: [],
        source: "None",
        reason: `YouTube /next HTTP ${nextRes.status}`
      };
    }

    const nextJson = await nextRes.json();
    const browseId = findLyricsBrowseId(nextJson);

    if (!browseId) {
      return {
        synced: false,
        lines: [],
        source: "None",
        reason: "Track has no lyrics endpoint on YouTube"
      };
    }

    const browseRes = await fetch(
      "https://music.youtube.com/youtubei/v1/browse?prettyPrint=false&ytm_mobile_sync=1",
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          context,
          browseId
        })
      }
    );

    if (!browseRes.ok) {
      return {
        synced: false,
        lines: [],
        source: "None",
        reason: `YouTube /browse HTTP ${browseRes.status}`
      };
    }

    const browseJson = await browseRes.json();
    const timedRenderer = findKeyRecursive(browseJson, "timedLyricsRenderer");
    const timedData =
      timedRenderer?.timedLyricsData ||
      findKeyRecursive(browseJson, "timedLyricsData");

    const sourceAttribution = extractSourceAttribution(timedRenderer || browseJson);

    if (Array.isArray(timedData) && timedData.length > 0) {
      const lines = timedData
        .filter((item) => item?.cueRange?.startTimeMilliseconds != null)
        .map((item) => ({
          text: (item.lyricLine || "").trim() || "♪",
          startTimeMs: Number(item.cueRange.startTimeMilliseconds),
          endTimeMs: Number(item.cueRange.endTimeMilliseconds || 0)
        }));

      if (lines.length > 0) {
        return {
          synced: true,
          lines,
          source: sourceAttribution || "YouTube Music",
          reason: `${lines.length} synced lines from YouTube Mobile`
        };
      }
    }

    return {
      synced: false,
      lines: [],
      source: sourceAttribution || "YouTube Static",
      reason: "YouTube only has unsynced static lyrics for this track"
    };
  } catch (err) {
    console.warn("[YTM Mobile Lyrics] InnerTube error:", err);
    return {
      synced: false,
      lines: [],
      source: "None",
      reason: `Fetch error: ${err.message}`
    };
  }
}

function extractSourceAttribution(obj) {
  const sourceMsg = findKeyRecursive(obj, "sourceMessage");
  const runs = sourceMsg?.runs;
  if (Array.isArray(runs)) {
    const text = runs.map((r) => r.text).join("").trim();
    if (text) return text;
  }
  return null;
}

function findLyricsBrowseId(obj) {
  if (!obj || typeof obj !== "object") return null;

  if (typeof obj.browseId === "string" && obj.browseId.startsWith("MPLYt")) {
    return obj.browseId;
  }

  for (const value of Object.values(obj)) {
    if (value && typeof value === "object") {
      const found = findLyricsBrowseId(value);
      if (found) return found;
    }
  }
  return null;
}

function findKeyRecursive(obj, targetKey) {
  if (!obj || typeof obj !== "object") return null;
  if (Object.prototype.hasOwnProperty.call(obj, targetKey)) {
    return obj[targetKey];
  }

  for (const value of Object.values(obj)) {
    if (value && typeof value === "object") {
      const found = findKeyRecursive(value, targetKey);
      if (found) return found;
    }
  }
  return null;
}
