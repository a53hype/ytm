(() => {
  const CONTAINER_CLASS = "ytm-mobile-lyrics-container";
  const HEADER_CLASS = "ytm-mobile-lyrics-header";
  const BODY_CLASS = "ytm-mobile-lyrics-body";
  const RESUME_BTN_CLASS = "ytm-ml-resume-btn";
  const OVERRIDE_HTML_CLASS = "ytm-mobile-lyrics-override";
  const SUPPRESSED_BLYRICS_POPUP_CLASS = "ytm-ml-suppressed-blyrics-popup";
  const SCROLL_HOST_CLASS = "ytm-ml-scroll-host";

  // BetterLyrics positions the active line at 37% of the visible lyrics viewport
  const DEFAULT_SCROLL_RATIO = 0.37;
  const SCROLL_ANIM_DURATION_MS = 600;
  const MANUAL_SCROLL_RESUME_MS = 3500;

  let isEnabled = true;
  let currentVideoId = "";
  let lastTrackSignature = "";
  let currentLyrics = null;
  let activeLineIndex = -1;

  let userScrolling = false;
  let userScrollTimeout = null;
  let trackCheckTimeout = null;
  let rafId = null;

  let scrollAnimRaf = null;
  let pendingInitialScroll = false;
  let wasContainerVisible = false;
  let boundScrollEl = null;

  chrome.storage.local.get(["enabled"], (res) => {
    isEnabled = typeof res.enabled === "boolean" ? res.enabled : true;
    if (typeof res.enabled !== "boolean") {
      chrome.storage.local.set({ enabled: true });
    }
    applyState();
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes.enabled) {
      isEnabled = Boolean(changes.enabled.newValue);
      applyState();
    }
  });

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "FORCE_REFRESH_LYRICS") {
      currentVideoId = "";
      lastTrackSignature = "";
      currentLyrics = null;
      checkTrackChange(true);
      sendResponse({ ok: true });
    }
    return false;
  });

  function setEnabled(nextState) {
    isEnabled = Boolean(nextState);
    chrome.storage.local.set({ enabled: isEnabled });
    applyState();
  }

  function isBetterLyricsInstalled() {
    return Boolean(
      document.querySelector(
        "ytmusic-app[blyrics-stylized], #blyrics-wrapper, .blyrics-container"
      )
    );
  }

  function syncBetterLyricsVariables(container) {
    if (!container) return;
    const sourceEl =
      document.querySelector(".blyrics-container") ||
      document.querySelector("#blyrics-wrapper") ||
      document.documentElement;

    const cs = getComputedStyle(sourceEl);
    const vars = [
      "--blyrics-font-family",
      "--blyrics-font-size",
      "--blyrics-font-weight",
      "--blyrics-line-height",
      "--blyrics-padding",
      "--blyrics-lyric-active-color",
      "--blyrics-lyric-inactive-color",
      "--blyrics-text-color",
      "--blyrics-target-scroll-pos-ratio"
    ];

    for (const v of vars) {
      const val = cs.getPropertyValue(v).trim();
      if (val) {
        container.style.setProperty(v, val);
      } else {
        container.style.removeProperty(v);
      }
    }
  }

  function suppressBetterLyricsPopups(active) {
    const playerPage = document.querySelector("ytmusic-player-page");
    if (!playerPage) return;

    if (!active) {
      playerPage
        .querySelectorAll(`.${SUPPRESSED_BLYRICS_POPUP_CLASS}`)
        .forEach((el) => el.classList.remove(SUPPRESSED_BLYRICS_POPUP_CLASS));
      return;
    }

    const candidates = playerPage.querySelectorAll(
      'button, [role="button"], #autoscroll-resume-button, .autoscroll-resume-button, [id*="autoscroll"], [class*="autoscroll"]'
    );
    candidates.forEach((el) => {
      if (el.closest(`.${CONTAINER_CLASS}`)) return;
      const text = (el.textContent || "").trim().toLowerCase();
      if (
        text === "resume autoscroll" ||
        text === "sync lyrics" ||
        el.id?.toLowerCase().includes("autoscroll") ||
        (typeof el.className === "string" && el.className.toLowerCase().includes("autoscroll"))
      ) {
        el.classList.add(SUPPRESSED_BLYRICS_POPUP_CLASS);
      }
    });
  }

  function getTargetScrollRatio(container) {
    if (container) {
      const raw = getComputedStyle(container)
        .getPropertyValue("--blyrics-target-scroll-pos-ratio")
        .trim();
      const parsed = parseFloat(raw);
      if (Number.isFinite(parsed) && parsed > 0 && parsed < 0.9) {
        return parsed;
      }
    }
    return DEFAULT_SCROLL_RATIO;
  }

  function getLocaleParams() {
    const htmlLang = document.documentElement.lang || navigator.language || "en-US";
    const parts = htmlLang.split("-");
    const hl = parts[0] || "en";
    const gl = (parts[1] || "US").toUpperCase();
    return { hl, gl };
  }

  function extractVideoIdFromUrl(urlStr) {
    if (!urlStr) return null;
    try {
      const u = new URL(urlStr, window.location.origin);
      const v = u.searchParams.get("v");
      if (v && /^[a-zA-Z0-9_-]{11}$/.test(v)) return v;
    } catch {}
    return null;
  }

  /**
   * Resolve the live playing videoId from active player DOM elements FIRST.
   * YouTube Music often leaves `window.location.search` (?v=...) stuck on the first song
   * when advancing through a queue/radio/album, so URL params must be checked LAST.
   */
  function getTrackInfo() {
    let videoId = null;

    // 1. Live HTML5 player title link (#movie_player / ytmusic-player)
    const titleLinks = document.querySelectorAll(
      "#movie_player a.ytp-title-link, ytmusic-player a.ytp-title-link, ytmusic-player-bar a.ytp-title-link"
    );
    for (const link of titleLinks) {
      const v = extractVideoIdFromUrl(link.href);
      if (v) {
        videoId = v;
        break;
      }
    }

    // 2. Live player custom element attributes
    if (!videoId) {
      const playerEls = [
        document.querySelector("ytmusic-player-page"),
        document.querySelector("ytmusic-player"),
        document.querySelector("ytmusic-player-bar")
      ];
      for (const el of playerEls) {
        const attrId = el?.getAttribute("video-id");
        if (attrId && /^[a-zA-Z0-9_-]{11}$/.test(attrId)) {
          videoId = attrId;
          break;
        }
      }
    }

    // 3. Player bar thumbnail URL (/vi/<11-char-id>/)
    if (!videoId) {
      const thumbImg = document.querySelector("ytmusic-player-bar img.image");
      const match = thumbImg?.src?.match(/\/vi\/([a-zA-Z0-9_-]{11})\//);
      if (match) videoId = match[1];
    }

    // 4. Canonical link tag
    if (!videoId) {
      const canonical = document.querySelector('link[rel="canonical"]');
      videoId = extractVideoIdFromUrl(canonical?.href);
    }

    // 5. Fallback: URL query param ?v= (may remain static during queue playback)
    if (!videoId) {
      videoId = extractVideoIdFromUrl(window.location.href);
    }

    const titleEl = document.querySelector(
      "ytmusic-player-bar .title.ytmusic-player-bar"
    );
    const bylineEl = document.querySelector(
      "ytmusic-player-bar .byline.ytmusic-player-bar"
    );

    const title = titleEl?.textContent?.trim() || "";
    const artist = bylineEl?.textContent?.split("•")[0]?.trim() || "";

    return { videoId: videoId || "", title, artist };
  }

  function findPlayerLyricsTab() {
    const playerPage = document.querySelector("ytmusic-player-page");
    if (!playerPage) return null;

    const explicitLyricsTab = playerPage.querySelector(
      'ytmusic-tab-renderer[page-type="MUSIC_PAGE_TYPE_TRACK_LYRICS"]'
    );
    if (explicitLyricsTab) return explicitLyricsTab;

    const sidePanelTabs = playerPage.querySelectorAll(
      "#side-panel ytmusic-tab-renderer, #tabsContent ytmusic-tab-renderer"
    );
    if (sidePanelTabs.length >= 2) {
      return sidePanelTabs[1];
    }

    return null;
  }

  function getScrollParent(tab, container = null) {
    const startNode = container || tab;
    if (!startNode) return null;

    let el = startNode.parentElement;
    const candidates = [];

    while (el && el !== document.body && el !== document.documentElement) {
      const style = getComputedStyle(el);
      const oy = style.overflowY;
      const isScrollableStyle = oy === "auto" || oy === "scroll" || oy === "overlay";

      if (isScrollableStyle && el.clientHeight > 0) {
        candidates.push(el);
        if (el.scrollHeight > el.clientHeight + 5) {
          return el;
        }
      }

      if (el.id === "side-panel" || el.tagName.toLowerCase() === "ytmusic-player-page") {
        break;
      }
      el = el.parentElement;
    }

    const tabRenderer = tab?.closest("#tab-renderer");
    if (tabRenderer && tabRenderer.clientHeight > 0 && tabRenderer.scrollHeight > tabRenderer.clientHeight + 5) {
      return tabRenderer;
    }

    return candidates[0] || tabRenderer || null;
  }

  function bindScrollHost(scrollParent, container) {
    if (!scrollParent || scrollParent === boundScrollEl) return;

    if (boundScrollEl) {
      boundScrollEl.classList.remove(SCROLL_HOST_CLASS);
    }
    boundScrollEl = scrollParent;
    scrollParent.classList.add(SCROLL_HOST_CLASS);

    if (scrollParent.dataset.ytmMlUserInputBound === "1") return;
    scrollParent.dataset.ytmMlUserInputBound = "1";

    const onHumanScrollInput = () => {
      if (!isEnabled || !currentLyrics?.synced) return;
      const currentContainer = document.querySelector(`.${CONTAINER_CLASS}`) || container;
      setManualScrollPause(currentContainer, true);
    };

    scrollParent.addEventListener("wheel", onHumanScrollInput, { passive: true });
    scrollParent.addEventListener("touchmove", onHumanScrollInput, { passive: true });
    scrollParent.addEventListener(
      "pointerdown",
      (e) => {
        const rect = scrollParent.getBoundingClientRect();
        if (e.clientX >= rect.right - 20) {
          onHumanScrollInput();
        }
      },
      { passive: true }
    );
  }

  function smoothScrollTo(scrollParent, targetTop, duration = SCROLL_ANIM_DURATION_MS) {
    if (!scrollParent) return false;

    scrollParent.style.setProperty("scroll-behavior", "auto", "important");

    if (scrollAnimRaf) {
      cancelAnimationFrame(scrollAnimRaf);
      scrollAnimRaf = null;
    }

    const startTop = scrollParent.scrollTop;
    const maxScroll = Math.max(0, scrollParent.scrollHeight - scrollParent.clientHeight);
    if (maxScroll <= 0) return false;

    const clampedTarget = Math.max(0, Math.min(targetTop, maxScroll));
    const delta = clampedTarget - startTop;

    if (Math.abs(delta) < 1) return true;

    const startTime = performance.now();

    const easeInOutCubic = (t) =>
      t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;

    const step = (now) => {
      const elapsed = now - startTime;
      const progress = Math.min(1, elapsed / duration);
      scrollParent.scrollTop = startTop + delta * easeInOutCubic(progress);

      if (progress < 1) {
        scrollAnimRaf = requestAnimationFrame(step);
      } else {
        scrollParent.scrollTop = clampedTarget;
        scrollAnimRaf = null;
      }
    };

    scrollAnimRaf = requestAnimationFrame(step);
    return true;
  }

  function scrollLineIntoFocus(tab, container, activeEl, instant = false) {
    const scrollParent = getScrollParent(tab, container);
    if (!scrollParent || !activeEl) return false;

    bindScrollHost(scrollParent, container);

    if (scrollParent.clientHeight <= 0 || scrollParent.scrollHeight <= scrollParent.clientHeight + 5) {
      return false;
    }

    const parentRect = scrollParent.getBoundingClientRect();
    const lineRect = activeEl.getBoundingClientRect();
    if (lineRect.height <= 0) return false;

    const ratio = getTargetScrollRatio(container);
    const desiredLineTopInViewport =
      parentRect.top + scrollParent.clientHeight * ratio - lineRect.height / 2;
    const offsetDelta = lineRect.top - desiredLineTopInViewport;
    const targetScrollTop = scrollParent.scrollTop + offsetDelta;

    if (instant) {
      scrollParent.style.setProperty("scroll-behavior", "auto", "important");
      scrollParent.scrollTop = Math.max(0, targetScrollTop);
      return true;
    }

    return smoothScrollTo(scrollParent, targetScrollTop, SCROLL_ANIM_DURATION_MS);
  }

  function setManualScrollPause(container, paused) {
    userScrolling = paused;
    clearTimeout(userScrollTimeout);

    const activeContainer = container || document.querySelector(`.${CONTAINER_CLASS}`);
    const resumeBtn = activeContainer?.querySelector(`.${RESUME_BTN_CLASS}`);
    if (resumeBtn) {
      const showBtn = Boolean(paused && isEnabled && currentLyrics?.synced);
      resumeBtn.classList.toggle("visible", showBtn);
      resumeBtn.disabled = !showBtn;
    }

    if (paused) {
      if (scrollAnimRaf) {
        cancelAnimationFrame(scrollAnimRaf);
        scrollAnimRaf = null;
      }
      userScrollTimeout = setTimeout(() => {
        setManualScrollPause(activeContainer, false);
        const tab = findPlayerLyricsTab();
        const activeEl = activeContainer?.querySelector(".ytm-mobile-lyric-line.blyrics--active");
        if (tab && activeEl) {
          scrollLineIntoFocus(tab, activeContainer, activeEl, false);
        }
      }, MANUAL_SCROLL_RESUME_MS);
    }
  }

  function ensureLyricsTabClickable() {
    const playerPage = document.querySelector("ytmusic-player-page");
    if (!playerPage) return;
    const paperTabs = playerPage.querySelectorAll("tp-yt-paper-tab");
    if (paperTabs.length >= 2 && paperTabs[1].hasAttribute("disabled")) {
      paperTabs[1].removeAttribute("disabled");
      paperTabs[1].removeAttribute("aria-disabled");
      paperTabs[1].style.pointerEvents = "auto";
      paperTabs[1].style.opacity = "1";
    }
  }

  function ensureContainer(tab) {
    let container = tab.querySelector(`.${CONTAINER_CLASS}`);
    if (!container) {
      container = document.createElement("div");
      container.className = CONTAINER_CLASS;

      // Sticky top control row: left status/toggle pill + right "Return to autoscroll" button.
      // Lives in the exact same clickable layer as the toggle switch and never overlaps lyrics or player bar.
      const header = document.createElement("div");
      header.className = HEADER_CLASS;
      header.innerHTML = `
        <div class="ytm-ml-pill">
          <div class="ytm-ml-header-left">
            <span class="ytm-ml-dot"></span>
            <span class="ytm-ml-title">YT Mobile Sync</span>
            <span class="ytm-ml-sep">•</span>
            <span class="ytm-ml-status">Active</span>
          </div>
          <label class="ytm-ml-switch" title="Prioritize YouTube Mobile Synced Lyrics over BetterLyrics">
            <input type="checkbox" class="ytm-ml-checkbox" />
            <span class="ytm-ml-slider"></span>
          </label>
        </div>
        <button type="button" class="${RESUME_BTN_CLASS}" disabled title="Snap back to the active lyric line">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <polyline points="1 4 1 10 7 10"></polyline>
            <path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"></path>
          </svg>
          <span>Return to autoscroll</span>
        </button>
      `;

      const checkbox = header.querySelector(".ytm-ml-checkbox");
      checkbox.checked = isEnabled;
      checkbox.addEventListener("change", (e) => {
        setEnabled(e.target.checked);
      });

      const resumeBtn = header.querySelector(`.${RESUME_BTN_CLASS}`);
      resumeBtn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        setManualScrollPause(container, false);
        const currentTab = findPlayerLyricsTab() || tab;
        const activeEl = container.querySelector(".ytm-mobile-lyric-line.blyrics--active");
        if (currentTab && activeEl) {
          scrollLineIntoFocus(currentTab, container, activeEl, false);
        }
      });

      const body = document.createElement("div");
      body.className = BODY_CLASS;

      container.appendChild(header);
      container.appendChild(body);

      tab.prepend(container);
    }

    syncBetterLyricsVariables(container);

    const checkbox = container.querySelector(".ytm-ml-checkbox");
    if (checkbox && checkbox.checked !== isEnabled) {
      checkbox.checked = isEnabled;
    }
    return container;
  }

  function updateHeaderStatus(container, stateClass, statusText) {
    if (!container) return;
    container.dataset.state = stateClass;
    const statusEl = container.querySelector(".ytm-ml-status");
    if (statusEl) {
      statusEl.textContent = statusText;
    }
    const checkbox = container.querySelector(".ytm-ml-checkbox");
    if (checkbox) {
      checkbox.checked = isEnabled;
    }
  }

  function applyState() {
    const tab = findPlayerLyricsTab();
    if (!tab) return;

    const container = ensureContainer(tab);
    const body = container.querySelector(`.${BODY_CLASS}`);

    if (!isEnabled) {
      document.documentElement.classList.remove(OVERRIDE_HTML_CLASS);
      suppressBetterLyricsPopups(false);
      setManualScrollPause(container, false);
      pendingInitialScroll = false;
      if (body) body.innerHTML = "";
      updateHeaderStatus(
        container,
        "off",
        isBetterLyricsInstalled() ? "Off (BetterLyrics)" : "Off"
      );
      return;
    }

    if (!currentLyrics) {
      document.documentElement.classList.add(OVERRIDE_HTML_CLASS);
      suppressBetterLyricsPopups(true);
      setManualScrollPause(container, false);
      if (body) body.innerHTML = "";
      updateHeaderStatus(container, "loading", "Syncing...");
      if (currentVideoId) {
        fetchLyricsForVideo(currentVideoId, false);
      }
      return;
    }

    if (currentLyrics.synced && Array.isArray(currentLyrics.lines) && currentLyrics.lines.length > 0) {
      document.documentElement.classList.add(OVERRIDE_HTML_CLASS);
      suppressBetterLyricsPopups(true);
      ensureLyricsTabClickable();
      updateHeaderStatus(
        container,
        "active",
        `${currentLyrics.lines.length} lines`
      );
      renderLyricLines(tab, container, body, currentLyrics);
    } else {
      document.documentElement.classList.remove(OVERRIDE_HTML_CLASS);
      suppressBetterLyricsPopups(false);
      setManualScrollPause(container, false);
      pendingInitialScroll = false;
      if (body) body.innerHTML = "";
      updateHeaderStatus(
        container,
        "fallback",
        isBetterLyricsInstalled() ? "Fallback (BetterLyrics)" : "No YT timestamps"
      );
    }
  }

  function renderLyricLines(tab, container, body, lyricsData) {
    if (!body) return;
    activeLineIndex = -1;
    setManualScrollPause(container, false);
    pendingInitialScroll = true;
    body.innerHTML = "";

    const list = document.createElement("div");
    list.className = "ytm-mobile-lyrics-list";

    lyricsData.lines.forEach((line, index) => {
      const lineEl = document.createElement("div");
      lineEl.className = "ytm-mobile-lyric-line";
      lineEl.dataset.index = String(index);
      lineEl.dataset.time = String(line.startTimeMs / 1000);
      lineEl.textContent = line.text;

      lineEl.addEventListener("click", () => {
        const video = document.querySelector("video");
        if (video && typeof line.startTimeMs === "number") {
          video.currentTime = line.startTimeMs / 1000;
          if (video.paused) video.play().catch(() => {});
          setManualScrollPause(container, false);
          updateActiveLine(true, false);
        }
      });

      list.appendChild(lineEl);
    });

    const footer = document.createElement("div");
    footer.className = "ytm-ml-footer";
    footer.textContent = lyricsData.source.toLowerCase().startsWith("source:")
      ? lyricsData.source
      : `Source: ${lyricsData.source}`;
    list.appendChild(footer);

    body.appendChild(list);

    const scrollParent = getScrollParent(tab, container);
    if (scrollParent) {
      scrollParent.style.setProperty("scroll-behavior", "auto", "important");
      scrollParent.scrollTop = 0;
    }

    requestAnimationFrame(() => {
      updateActiveLine(true, false);
    });
  }

  function updateActiveLine(forceResync = false, instantScroll = false) {
    if (!isEnabled || !currentLyrics?.synced) return;

    const tab = findPlayerLyricsTab();
    const video = document.querySelector("video");
    if (!tab || !video) return;

    const container = tab.querySelector(`.${CONTAINER_CLASS}`);
    if (!container) return;

    suppressBetterLyricsPopups(true);

    const isNowVisible = container.offsetParent !== null && container.clientHeight > 0;
    const justBecameVisible = isNowVisible && !wasContainerVisible;
    wasContainerVisible = isNowVisible;

    const currentMs = video.currentTime * 1000 + 140;
    const lines = currentLyrics.lines;

    let newIndex = -1;
    for (let i = 0; i < lines.length; i++) {
      if (currentMs >= lines[i].startTimeMs) {
        newIndex = i;
      } else {
        break;
      }
    }

    const lineChanged = newIndex !== activeLineIndex;
    activeLineIndex = newIndex;

    const lineEls = container.querySelectorAll(".ytm-mobile-lyric-line");
    if (lineChanged || forceResync) {
      lineEls.forEach((el, idx) => {
        const isActive = idx === activeLineIndex;
        const isPast = activeLineIndex >= 0 && idx < activeLineIndex;
        el.classList.toggle("blyrics--active", isActive);
        el.classList.toggle("blyrics--past", isPast);
      });
    }

    const shouldScroll =
      lineChanged || forceResync || justBecameVisible || pendingInitialScroll;

    if (activeLineIndex >= 0 && !userScrolling && shouldScroll && lineEls[activeLineIndex]) {
      const didScroll = scrollLineIntoFocus(
        tab,
        container,
        lineEls[activeLineIndex],
        instantScroll
      );
      if (didScroll) {
        pendingInitialScroll = false;
      }
    }
  }

  function startSyncLoop() {
    if (rafId) cancelAnimationFrame(rafId);
    const tick = () => {
      updateActiveLine(false, false);
      rafId = requestAnimationFrame(tick);
    };
    rafId = requestAnimationFrame(tick);
  }

  function fetchLyricsForVideo(videoId, forceRefresh = false) {
    const { hl, gl } = getLocaleParams();
    const { title, artist } = getTrackInfo();

    chrome.runtime.sendMessage(
      {
        type: "FETCH_YOUTUBE_MOBILE_LYRICS",
        videoId,
        title,
        artist,
        hl,
        gl,
        forceRefresh
      },
      (response) => {
        if (currentVideoId !== videoId) return;

        if (chrome.runtime.lastError || !response?.ok) {
          currentLyrics = { synced: false, lines: [], source: "Error" };
        } else {
          currentLyrics = response.data;
        }
        applyState();
      }
    );
  }

  function checkTrackChange(forceRefresh = false) {
    const { videoId, title, artist } = getTrackInfo();
    const tab = findPlayerLyricsTab();
    if (!tab) return;

    ensureContainer(tab);

    if (!videoId) return;

    const trackSignature = `${videoId}::${title}::${artist}`;

    if (!forceRefresh && videoId === currentVideoId) {
      // If song title/artist changed in player bar, schedule a quick re-poll in case videoId attribute lagged
      if (trackSignature !== lastTrackSignature) {
        lastTrackSignature = trackSignature;
        setTimeout(() => checkTrackChange(false), 250);
      }

      if (isEnabled && currentLyrics?.synced && !tab.querySelector(".ytm-mobile-lyric-line")) {
        applyState();
      }
      return;
    }

    currentVideoId = videoId;
    lastTrackSignature = trackSignature;
    currentLyrics = null;
    activeLineIndex = -1;
    userScrolling = false;
    wasContainerVisible = false;
    pendingInitialScroll = true;

    if (!isEnabled) {
      applyState();
      return;
    }

    applyState();
    fetchLyricsForVideo(videoId, forceRefresh);
  }

  function scheduleTrackCheck() {
    clearTimeout(trackCheckTimeout);
    trackCheckTimeout = setTimeout(() => checkTrackChange(false), 120);
  }

  const observer = new MutationObserver((mutations) => {
    const relevant = mutations.some((m) => {
      const target = m.target instanceof Element ? m.target : m.target.parentElement;
      if (!target) return false;
      return !target.closest(`.blyrics-container, .${CONTAINER_CLASS}`);
    });
    if (relevant) {
      scheduleTrackCheck();
    }
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["video-id", "href", "src"]
  });

  // Catch HTML5 <video> track transitions immediately
  document.addEventListener("loadedmetadata", scheduleTrackCheck, true);
  document.addEventListener("emptied", scheduleTrackCheck, true);
  window.addEventListener("yt-navigate-finish", scheduleTrackCheck);

  setInterval(() => checkTrackChange(false), 900);
  startSyncLoop();
})();
